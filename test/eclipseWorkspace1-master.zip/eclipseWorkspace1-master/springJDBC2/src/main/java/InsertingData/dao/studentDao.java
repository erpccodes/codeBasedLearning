package InsertingData.dao;

import InsertingData.entity.Student;

public interface studentDao {
	public int insert(Student student);
	public int update(Student student);

}
