package restApiFirst.exception;

public class CustomeremailNotFoundException extends Exception{
	
	public CustomeremailNotFoundException(String msg) {
		super(msg);
	}

}
