package assignmentDemo;

public class MemberAccount {
	
	String name;
    int accountNo;
    Book[] borrowed;

}
