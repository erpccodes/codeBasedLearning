package assignmentDemo;

public class Library {

    String libraryName;
    String address;
    String libraryRegno;
    Book[] books;
    
    
    
    public Book[] getBooks() {
    	return books;
    };
    
    
    
    public static void showAllBooks() {
    	
    }; 
}
