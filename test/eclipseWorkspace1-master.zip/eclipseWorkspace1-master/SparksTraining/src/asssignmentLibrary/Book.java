package asssignmentLibrary;

public class Book {
	int bookIsbnNo;
    String author;
    String publisher;
}
